## Folder for Interbotix widowx200 gazebo simulation code using ROS melodic

## Additional package:
**ROS Melodic**
 
Install ROS melodic using the steps given in this link  http://wiki.ros.org/melodic/Installation/Ubuntu

**Gnuplot**

for Installation run the following command
```
$ sudo apt-get install -y gnuplot
```
**Eigen Library**  

for Installation run the following command
```
$ sudo apt-get install libeigen3-dev
```
## To build for the first time
Open a terminal on your computer and create a new catkin workspace called `interbotix_ws`
```
$ mkdir -p ~/interbotix_ws/src
$ cd ~/interbotix_ws/
$ catkin_make
```
Move to ~/interbotix_ws/src folder

```
$ cd src
```

copy the Interbotix_src folder from the drive to the src folder

Then run the catkin_make command to build the workspace

```
$ catkin_make
```
to Make sure that your new workspace is sourced every time a terminal is opened
```
$ source ~/interbotix_ws/devel/setup.bash
$ echo "source ~/interbotix_ws/devel/setup.bash" >> ~/.bashrc
```

Before doing another `catkin_make`, make sure that all required dependencies are installed. `rosdep` will be used to do this efficiently.
```
$ cd ~/interbotix_ws
$ rosdep update
$ rosdep install --from-paths src --ignore-src -r -y
```
Now that all the dependencies are installed, it's time to build!
```
$ cd ~/interbotix_ws
$ catkin_make
$ source ~/.bashrc
```
## To run the gazebo simuation with robotic arm in standalone mode
run the command 
```
$ cd ~/interbotix_ws

$ roslaunch interbotix_gazebo gazebo.launch
```
