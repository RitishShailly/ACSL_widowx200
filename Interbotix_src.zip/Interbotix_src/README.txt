##ReadMe for Main App.

LIBRARY SETUP WILL BE NEEDED FOR ALL THE APPS. FOLLOW INSTRUCTIONS IN THE USER MANUAL

Build library for ROS, WidowX 200 (Dynamixel SDK) as show in'Setup' sections 'Gazebo' and 'Actual Robot'.

Launch MATLAB via Terminal via the command :  $ matlab -r "cd ~/interbotix_ws/src/Interbotix_src/GUI/"   (refer page 22 of the WidowX 200 Manual)

'Robotic_Arm_Main.mlapp' in the current folder, Select the type of simulation/actual motion desired. 

Apps for Gazebo/Simulink/Robotic arm are also provided.
Gazebo : Gazebo_Arm_app.mlapp
Simulink: Simulink_arm_app.mlapp
Robotic Arm : real_arm_app.mlapp

Read the GUI section in the Manual for more details  
