%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This code produces solves numerically the equations of motion of the
% WidowX 200 robotic arm controlled using the inverse-dynamics (direct
% cancellation) control technique and applies it to a Simulink simulation
% model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
clc
close all

format long

% Which Trajectory Method? 0-LSPB 1-Quintic Polynomial
which_path=1;

% Do not modify initial position, velocity and acceleration
q0 = [0,0,1.8,2.1,0]; %initial position corresponds to all links oriented horizontally outward in the negative y direction
v0 = [0,0,0,0,0];
alpha0 = [0,0,0,0,0];

% Parameters for inverse kinematics -- do not change
d1 = 0.11325; %vertical length of shoulder link
a2 = 0.20616; %length of upper arm link
a3 = 0.2; %length of forearm link
d5 = 0.065 + 0.10915; %length of wrist, gripper, and finger together

% Enter desired end effector position (cartesian)
% End effector initial position is [0;-.18;.49]
p = [0.3;.1;.27]; %m

% Enter desired gripper angle
% Initial gripper angle is 0
alpha = 0; 

% Enter desired axis of end effector
% Initial end effector axis is [0;.4;.07]
z_5 = [0;1;.2];
z_5 = z_5/norm(z_5);
%%
% Call function to check whether desired end effector position is within
% the range of the robotic arm
[bounds,bounds_dist_from_center,point_dist_from_center] = check_position(p);
%%
% Call function to compute final joint angles based on desired end effector
% position using inverse kinematics
[qf] = inverse_kinematics(alpha,z_5,p,d1,a2,a3,d5,bounds,bounds_dist_from_center,point_dist_from_center);

% Final velocity and acceleration specified as zero
vf = [0,0,0,0,0];
alphaf = [0,0,0,0,0];

% Select simulation time
tf = 10;

% If using the quintic polynomial method, coefficients are calculated here
% (before simulation)
if which_path==1
    coefficients = quintic_polynomial(tf,q0,qf,v0,vf,alpha0,alphaf);
else
    coefficients = zeros(6,length(q0));
end

% Parameters for the PD controller 
% (omega - natural frequency, zeta - damping ratio)
omega_base = 2;             % Must be larger than zero
omega_shoulder = 4;         % Must be larger than zero
omega_elbow = 2.5;          % Must be larger than zero
omega_wrist = 1.5;          % Must be larger than zero
omega_gripper = 3;          % Must be larger than zero
zeta_base = .1;             % Must be larger than zero
zeta_shoulder = 5;          % Must be larger than zero
zeta_elbow = 2;             % Must be larger than zero
zeta_wrist = .7;            % Must be larger than zero
zeta_gripper = .7;          % Must be larger than zero
zeta = [zeta_base,zeta_shoulder,zeta_elbow,zeta_wrist,zeta_gripper]';
omega = [omega_base,omega_shoulder,omega_elbow,omega_wrist,omega_gripper]';

% Constructing Kp and Kd (gain matrices) based on omega and zeta
KP = diag([omega(1)^2,omega(2)^2,omega(3)^2,omega(4)^2,omega(5)^2]);
KD = diag([2*zeta(1)*omega(1),2*zeta(2)*omega(2),2*zeta(3)*omega(3),2*zeta(4)*omega(4),2*zeta(5)*omega(5)]);

% Ki gain matrix - penalizes previous error
KI_base = .5;       % Must be larger than zero
KI_shoulder = 20;    % Must be larger than zero
KI_elbow = 40;      % Must be larger than zero
KI_wrist = 10;      % Must be larger than zero
KI_gripper = .7;    % Must be larger than zero
KI = diag([KI_base,KI_shoulder,KI_elbow,KI_wrist,KI_gripper]);

% Parameters for the LQR controller
% (r11 applies to position error and r22 applies to velocity error)
% Increase to increase effort
r11_base = 1e4;             % Must be positive
r22_base = 100;             % Must be positive
R1_base = [r11_base,0;0,r22_base];

r11_shoulder = 1e5;         % Must be positive
r22_shoulder = 1e2;         % Must be positive
R1_shoulder = [r11_shoulder,0;0,r22_shoulder];

r11_elbow = 1e5;            % Must be positive
r22_elbow = 1e2;            % Must be positive
R1_elbow = [r11_elbow,0;0,r22_elbow];

r11_wrist = 5e4;            % Must be positive
r22_wrist = 1e3;            % Must be positive
R1_wrist = [r11_wrist,0;0,r22_wrist];

r11_gripper = 1e4;          % Must be positive
r22_gripper = 1e3;          % Must be positive
R1_gripper = [r11_gripper,0;0,r22_gripper];

% Increase r2 to decrease steady state error
r2_base = 1;                % Must be positive
r2_shoulder = 1e-5;           % Must be positive
r2_elbow = 1e-2;             % Must be positive
r2_wrist = 1;               % Must be positive
r2_gripper = 1;             % Must be positive

A1 = [0,1;-2*zeta_base*omega_base,-omega_base^2]; % A matrix for base
A2 = [0,1;-2*zeta_shoulder*omega_shoulder,-omega_shoulder^2]; % A matrix for shoulder
A3 = [0,1;-2*zeta_elbow*omega_elbow,-omega_elbow^2]; % A matrix for elbow
A4 = [0,1;-2*zeta_wrist*omega_wrist,-omega_wrist^2]; % A matrix for wrist
A5 = [0,1;-2*zeta_gripper*omega_gripper,-omega_gripper^2]; % A matrix for gripper

% Do not modify B, C, D
B = [0;1];
C = eye(2);
D = [0;0];

% Matlab representation of each link's dynamics
sys1 = ss(A1,B,C,D);
sys2 = ss(A2,B,C,D);
sys3 = ss(A3,B,C,D);
sys4 = ss(A4,B,C,D);
sys5 = ss(A5,B,C,D);

% Calculating gain matrices for LQR control (each link)
[K_LQRbase,~,~] = lqr(sys1,R1_base,r2_base,zeros(2,1));
[K_LQRshoulder,~,~] = lqr(sys2,R1_shoulder,r2_shoulder,zeros(2,1));
[K_LQRelbow,~,~] = lqr(sys3,R1_elbow,r2_elbow,zeros(2,1));
[K_LQRwrist,~,~] = lqr(sys4,R1_wrist,r2_wrist,zeros(2,1));
[K_LQRgripper,~,~] = lqr(sys5,R1_gripper,r2_gripper,zeros(2,1));

% Run Simulink model
sim_out = sim('widowx200_sim_model', 'StartTime', '0', 'StopTime', num2str(tf));

% Initialize the reference variables
t = sim_out.tout;
q_ref = zeros(length(t),length(q0));

% Compute reference trajectory (to be plotted alongside actual trajectory)
if which_path == 0
    for jj = 1:length(t)
        [q_ref(jj,:),~,~] = LSPB(tf,q0,qf,t(jj));
    end
else
    for jj = 1:length(t)
        q_ref(jj,:) = coefficients'*[1;t(jj);t(jj)^2;t(jj)^3;t(jj)^4;t(jj)^5];
    end
end

%--------------------------------------------------------------------------
% Plot results
%--------------------------------------------------------------------------
    
% Positions
    %base position
    set(figure,'Color','white')
    plot(sim_out.q_base,'b-',sim_out.tout,q_ref(:,1),'k-.','LineWidth',2)
    l= legend('$$q_1$$', '$$q_{1,{\rm ref}}$$');
    set(l,'interpreter','latex','fontsize',20);
    set(gca,'fontsize',15)
    xlabel('$$t \, {\rm [s]}$$','interpreter','latex','fontsize',20)
    axis tight

    %shoulder position
    set(figure,'Color','white')
    plot(sim_out.q_shoulder,'b-',sim_out.tout,q_ref(:,2),'k-.','LineWidth',2)
    l= legend('$$q_2$$', '$$q_{2,{\rm ref}}$$');
    set(l,'interpreter','latex','fontsize',20);
    set(gca,'fontsize',15)
    xlabel('$$t \, {\rm [s]}$$','interpreter','latex','fontsize',20)
    axis tight
    
    %elbow position
    set(figure,'Color','white')
    plot(sim_out.q_elbow,'b-',sim_out.tout,q_ref(:,3),'k-.','LineWidth',2)
    l= legend('$$q_3$$', '$$q_{3,{\rm ref}}$$');
    set(l,'interpreter','latex','fontsize',20);
    set(gca,'fontsize',15)
    xlabel('$$t \, {\rm [s]}$$','interpreter','latex','fontsize',20)
    axis tight

    %wrist position
    set(figure,'Color','white')
    plot(sim_out.q_wrist,'b-',sim_out.tout,q_ref(:,4),'k-.','LineWidth',2)
    l= legend('$$q_4$$', '$$q_{4,{\rm ref}}$$');
    set(l,'interpreter','latex','fontsize',20);
    set(gca,'fontsize',15)
    xlabel('$$t \, {\rm [s]}$$','interpreter','latex','fontsize',20)
    axis tight
    
    %gripper position
    set(figure,'Color','white')
    plot(sim_out.q_gripper,'b-',sim_out.tout,q_ref(:,5),'k-.','LineWidth',2)
    l= legend('$$q_5$$', '$$q_{5,{\rm ref}}$$');
    set(l,'interpreter','latex','fontsize',20);
    set(gca,'fontsize',15)
    xlabel('$$t \, {\rm [s]}$$','interpreter','latex','fontsize',20)
    axis tight

% Torques
    %base torque
    set(figure,'Color','white')
    plot(sim_out.u_base,'b-','LineWidth',2)
    l= legend('$$u_{base}$$');
    set(l,'interpreter','latex','fontsize',20);
    set(gca,'fontsize',15)
    xlabel('$$t \, {\rm [s]}$$','interpreter','latex','fontsize',20)
    axis tight

    %shoulder torque
    set(figure,'Color','white')
    plot(sim_out.u_shoulder,'b-','LineWidth',2)
    l= legend('$$u_{shoulder}$$');
    set(l,'interpreter','latex','fontsize',20);
    set(gca,'fontsize',15)
    xlabel('$$t \, {\rm [s]}$$','interpreter','latex','fontsize',20)
    axis tight
    
    %elbow torque
    set(figure,'Color','white')
    plot(sim_out.u_elbow,'b-','LineWidth',2)
    l= legend('$$u_{elbow}$$');
    set(l,'interpreter','latex','fontsize',20);
    set(gca,'fontsize',15)
    xlabel('$$t \, {\rm [s]}$$','interpreter','latex','fontsize',20)
    axis tight

    %wrist torque
    set(figure,'Color','white')
    plot(sim_out.u_wrist,'b-','LineWidth',2)
    l= legend('$$u_{wrist}$$');
    set(l,'interpreter','latex','fontsize',20);
    set(gca,'fontsize',15)
    xlabel('$$t \, {\rm [s]}$$','interpreter','latex','fontsize',20)
    axis tight
    
    %gripper torque
    set(figure,'Color','white')
    plot(sim_out.u_gripper,'b-','LineWidth',2)
    l= legend('$$u_{gripper}$$');
    set(l,'interpreter','latex','fontsize',20);
    set(gca,'fontsize',15)
    xlabel('$$t \, {\rm [s]}$$','interpreter','latex','fontsize',20)
    axis tight
